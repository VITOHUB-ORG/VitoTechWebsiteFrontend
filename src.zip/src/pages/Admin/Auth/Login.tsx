// src/pages/Admin/Auth/Login.tsx
import type { FormEvent } from "react";

export default function Login() {
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Hapa baadae utaweka logic ya ku-hit API ya login
    console.log("Login submit...");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-50">
      <div className="w-full max-w-sm rounded-2xl border border-slate-800 bg-slate-900/70 px-6 py-8 shadow-2xl shadow-slate-950/40">
        {/* Logo juu */}
        <div className="mb-6 flex justify-center">
          <img
            src="images/vt4-1.png"
            alt="VitoTech"
            className="h-10 w-auto"
          />
        </div>

        {/* Title ndogo tu ya ndani ya kampuni */}
        <h1 className="text-center text-lg font-semibold tracking-tight">
          VitoTech Admin Login
        </h1>

        <form className="mt-6 space-y-5" onSubmit={handleSubmit}>
          {/* Username */}
          <div>
            <label
              htmlFor="username"
              className="block text-xs font-semibold uppercase tracking-[0.18em] text-slate-300"
            >
              Username
            </label>
            <input
              id="username"
              type="text"
              required
              className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-50 outline-none ring-0 transition placeholder:text-slate-500 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/40"
              placeholder=" "
            />
          </div>

          {/* Password */}
          <div>
            <label
              htmlFor="password"
              className="block text-xs font-semibold uppercase tracking-[0.18em] text-slate-300"
            >
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              className="mt-2 w-full rounded-lg border border-slate-700 bg-slate-900/80 px-3 py-2.5 text-sm text-slate-50 outline-none ring-0 transition placeholder:text-slate-500 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-500/40"
              placeholder=" "
            />
          </div>

          {/* Login button */}
          <button
            type="submit"
            className="mt-2 inline-flex w-full items-center justify-center rounded-lg bg-indigo-500 px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.22em] text-white shadow-lg shadow-indigo-500/30 transition hover:bg-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/70 focus:ring-offset-2 focus:ring-offset-slate-950"
          >
            Login
          </button>
        </form>
      </div>
    </div>
  );
}
