// src/pages/Admin/SidebarTopbar.tsx
import { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { FiLayout, FiMail } from "react-icons/fi";

export type MessageStatus = "read" | "unread";

export type ContactMessage = {
  id: string;
  name: string;
  email: string;
  phone?: string;
  message: string;
  status: MessageStatus;
  createdAt: string;
};

export type MessagesOutletContext = {
  messages: ContactMessage[];
  total: number;
  unread: number;
  read: number;
  handleToggleStatus: (id: string) => void;
  handleMarkAllRead: () => void;
};

const INITIAL_MESSAGES: ContactMessage[] = [
  {
    id: "1",
    name: "Costantine Boniface",
    email: "costantine@example.com",
    phone: "+255 678 000 111",
    message:
      "Habari, ningependa kupata maelezo zaidi kuhusu AI automation kwa biashara yangu.",
    status: "unread",
    createdAt: "2024-11-18T09:30:00Z",
  },
  {
    id: "2",
    name: "Nicholaus Gilbert",
    email: "nicholaus@example.com",
    phone: "+255 712 333 444",
    message:
      "Naomba quotation ya kutengeneza mobile app (Android & iOS) kwa duka langu.",
    status: "read",
    createdAt: "2024-11-18T11:15:00Z",
  },
  {
    id: "3",
    name: "Mary Mwita",
    email: "mary@example.com",
    phone: "+255 765 555 666",
    message:
      "Nahitaji website + AI chatbot kwa taasisi yetu. Tunaweza kupanga meeting?",
    status: "unread",
    createdAt: "2024-11-19T08:05:00Z",
  },
];

export default function SidebarTopbar() {
  const [messages, setMessages] = useState<ContactMessage[]>(INITIAL_MESSAGES);

  const total = messages.length;
  const unread = messages.filter((m) => m.status === "unread").length;
  const read = total - unread;

  const handleToggleStatus = (id: string) => {
    setMessages((prev) =>
      prev.map((m) =>
        m.id === id
          ? { ...m, status: m.status === "unread" ? "read" : "unread" }
          : m
      )
    );
  };

  const handleMarkAllRead = () => {
    setMessages((prev) =>
      prev.map((m) =>
        m.status === "unread" ? { ...m, status: "read" } : m
      )
    );
  };

  const outletContext: MessagesOutletContext = {
    messages,
    total,
    unread,
    read,
    handleToggleStatus,
    handleMarkAllRead,
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <div className="flex min-h-screen flex-col">
        {/* TOP BAR – common kwa pages zote za admin */}
        <header className="flex h-14 items-center border-b border-slate-800 bg-slate-950/95 px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-500">
              <FiMail className="h-4 w-4 text-white" />
            </div>
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-400">
                VITOTECH
              </p>
              <p className="text-sm font-medium text-slate-50">
                Admin Messages
              </p>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-3 text-[11px] text-slate-400">
            <span className="hidden sm:inline">
              Total: {total} · Unread: {unread} · Read: {read}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-[11px] font-semibold uppercase tracking-wide text-slate-100">
              AD
            </div>
          </div>
        </header>

        {/* BODY: sidebar + main content */}
        <div className="flex flex-1">
          {/* SIDEBAR – ina links za Dashboard na Messages */}
          <aside className="hidden w-56 border-r border-slate-800 bg-slate-950/95 pt-4 md:block">
            <nav className="space-y-1 px-3 text-sm">
              <NavLink
                to="/admin"
                end
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-3 py-2 font-medium transition ${
                    isActive
                      ? "bg-slate-800 text-slate-50"
                      : "text-slate-300 hover:bg-slate-900"
                  }`
                }
              >
                <FiLayout className="h-4 w-4" />
                <span>Dashboard</span>
              </NavLink>

              <NavLink
                to="/admin/messages"
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-3 py-2 font-medium transition ${
                    isActive
                      ? "bg-slate-800 text-slate-50"
                      : "text-slate-300 hover:bg-slate-900"
                  }`
                }
              >
                <FiMail className="h-4 w-4" />
                <span>Messages</span>
                {unread > 0 && (
                  <span className="ml-auto rounded-full bg-amber-500/20 px-2 py-0.5 text-[11px] font-semibold text-amber-300">
                    {unread}
                  </span>
                )}
              </NavLink>
            </nav>
          </aside>

          {/* MAIN CONTENT – hapa ndiyo pages zitaingia kupitia routes */}
          <main className="flex-1 bg-slate-900/80 px-4 py-6 sm:px-6 lg:px-8">
            <Outlet context={outletContext} />
          </main>
        </div>
      </div>
    </div>
  );
}
