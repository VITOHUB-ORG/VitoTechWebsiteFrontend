// src/pages/Admin/Dashboard.tsx
import type { FC } from "react";
import { useOutletContext } from "react-router-dom";
import type { MessagesOutletContext } from "../Components/SidebarTopbar";

function useMessagesContext() {
  return useOutletContext<MessagesOutletContext>();
}

function formatDate(dateString: string) {
  const d = new Date(dateString);
  return d.toLocaleString();
}

const Dashboard: FC = () => {
  const { total, unread, read, messages } = useMessagesContext();
  const latest = messages.slice(0, 5);

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
          Dashboard
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Muhtasari wa messages zote zilizotumwa kutoka kwenye website.
        </p>
      </div>

      {/* Cards: Total / Unread / Read */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-400">
            Total Messages
          </p>
          <p className="mt-3 text-3xl font-semibold text-slate-50">
            {total}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Jumla ya messages zote ulizopokea.
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-300">
            Unread
          </p>
          <p className="mt-3 text-3xl font-semibold text-amber-300">
            {unread}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Messages ambazo hujazisoma bado.
          </p>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-300">
            Read
          </p>
          <p className="mt-3 text-3xl font-semibold text-emerald-300">
            {read}
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Messages ambazo tayari umeshazisoma.
          </p>
        </div>
      </div>

      {/* Latest messages */}
      <div className="mt-8">
        <h2 className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
          Latest Messages
        </h2>

        {latest.length === 0 ? (
          <p className="mt-3 text-sm text-slate-500">
            Bado hujapokea messages yoyote.
          </p>
        ) : (
          <div className="mt-3 divide-y divide-slate-800 rounded-xl border border-slate-800 bg-slate-900/60">
            {latest.map((msg) => (
              <div
                key={msg.id}
                className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-start sm:justify-between"
              >
                <div>
                  <p className="text-sm font-semibold text-slate-50">
                    {msg.name}
                  </p>
                  <p className="text-xs text-slate-400">{msg.email}</p>
                  {msg.phone && (
                    <p className="text-xs text-slate-500">{msg.phone}</p>
                  )}
                  <p className="mt-2 line-clamp-2 text-sm text-slate-300">
                    {msg.message}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1 text-right">
                  <span
                    className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${
                      msg.status === "unread"
                        ? "bg-amber-500/10 text-amber-300 ring-1 ring-amber-500/40"
                        : "bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-500/40"
                    }`}
                  >
                    {msg.status === "unread" ? "Unread" : "Read"}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    {formatDate(msg.createdAt)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
