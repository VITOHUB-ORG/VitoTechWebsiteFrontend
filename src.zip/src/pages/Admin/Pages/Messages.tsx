// src/pages/Admin/Messages.tsx
import type { FC } from "react";
import { useOutletContext } from "react-router-dom";
import { FiCheckCircle } from "react-icons/fi";
import type { MessagesOutletContext } from "../Components/SidebarTopbar";

function useMessagesContext() {
  return useOutletContext<MessagesOutletContext>();
}

function formatDate(dateString: string) {
  const d = new Date(dateString);
  return d.toLocaleString();
}

const Messages: FC = () => {
  const {
    messages,
    handleToggleStatus,
    handleMarkAllRead,
  } = useMessagesContext();

  return (
    <div className="flex h-full flex-col">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-50">
            Messages
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            Orodha ya messages zote zilizokuja kupitia contact forms kwenye
            website.
          </p>
        </div>

        <button
          type="button"
          onClick={handleMarkAllRead}
          className="inline-flex items-center gap-2 rounded-lg border border-emerald-500/60 bg-emerald-500/10 px-3 py-2 text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-200 hover:bg-emerald-500/20"
        >
          <FiCheckCircle className="h-4 w-4" />
          Mark all as read
        </button>
      </div>

      <div className="flex-1 overflow-hidden rounded-xl border border-slate-800 bg-slate-900/70">
        {messages.length === 0 ? (
          <div className="flex h-40 items-center justify-center">
            <p className="text-sm text-slate-500">
              Hakuna messages kwa sasa. Zitatokea hapa zikishatumwa kwenye
              site.
            </p>
          </div>
        ) : (
          <div className="max-h-[540px] overflow-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="sticky top-0 bg-slate-950/95 text-xs uppercase tracking-[0.14em] text-slate-400">
                <tr>
                  <th className="px-4 py-3">From</th>
                  <th className="px-4 py-3">Contact</th>
                  <th className="px-4 py-3">Message</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {messages.map((msg) => (
                  <tr key={msg.id} className="align-top">
                    <td className="px-4 py-3 text-slate-50">
                      <div className="font-semibold">{msg.name}</div>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-300">
                      <div>{msg.email}</div>
                      {msg.phone && (
                        <div className="mt-1 text-slate-500">
                          {msg.phone}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm text-slate-200">
                      <p className="line-clamp-3">{msg.message}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          msg.status === "unread"
                            ? "bg-amber-500/10 text-amber-300 ring-1 ring-amber-500/40"
                            : "bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-500/40"
                        }`}
                      >
                        {msg.status === "unread" ? "Unread" : "Read"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {formatDate(msg.createdAt)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        onClick={() => handleToggleStatus(msg.id)}
                        className="rounded-md border border-slate-600 px-3 py-1.5 text-xs font-semibold text-slate-100 transition hover:border-indigo-500 hover:bg-indigo-500/10 hover:text-indigo-200"
                      >
                        {msg.status === "unread"
                          ? "Mark as read"
                          : "Mark as unread"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Messages;
