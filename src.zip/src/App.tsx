import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Admin/Auth/Login";

import SidebarTopbar from "./pages/Admin/Components/SidebarTopbar";
import Dashboard from "./pages/Admin/Pages/Dashboard";
import Messages from "./pages/Admin/Pages/Messages";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<SidebarTopbar />}>
          <Route index element={<Dashboard />} />
          <Route path="messages" element={<Messages />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
