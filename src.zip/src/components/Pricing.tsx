export default function Pricing(){
  return (
     {/* <section className="section section-sm section-bottom-70 section-fluid bg-default">
            <div className="container">
              <h2>Pricing</h2>
              <div className="row row-30 justify-content-center">
                <div className="col-md-6 col-lg-5 col-xl-4">
                  <div className="box-pricing box-pricing-black">
                    <div className="box-pricing-body">
                      <h5 className="box-pricing-title">basic</h5>
                      <h3 className="box-pricing-price">$500.00</h3>
                      <div className="box-pricing-time">starting at</div>
                      <div className="box-pricing-divider">
                        <div className="divider"></div><span>Basic</span>
                      </div>
                      <ul className="box-pricing-list">
                        <li className="active">Concept development</li>
                        <li className="active">UI design</li>
                        <li>Configuration management</li>
                        <li>Software quality assurance</li>
                        <li>App integration</li>
                      </ul>
                    </div>
                    <div className="box-pricing-button"><a className="button button-lg button-block button-gray-4" href="#">Get started</a></div>
                  </div>
                </div>
                <div className="col-md-6 col-lg-5 col-xl-4">
                  <div className="box-pricing box-pricing-black box-pricing-popular">
                    <div className="box-pricing-body">
                      <h5 className="box-pricing-title">Optimal</h5>
                      <h3 className="box-pricing-price">$800.00</h3>
                      <div className="box-pricing-time">starting at</div>
                      <div className="box-pricing-divider">
                        <div className="divider"></div><span>Optimal</span>
                      </div>
                      <ul className="box-pricing-list">
                        <li className="active">Concept development</li>
                        <li className="active">UI design</li>
                        <li className="active">Configuration management</li>
                        <li className="active">Software quality assurance</li>
                        <li>App integration</li>
                      </ul>
                    </div>
                    <div className="box-pricing-button"><a className="button button-lg button-block button-primary" href="#">Get started</a></div>
                    <div className="box-pricing-badge">popular</div>
                  </div>
                </div>
                <div className="col-md-6 col-lg-5 col-xl-4">
                  <div className="box-pricing box-pricing-black">
                    <div className="box-pricing-body">
                      <h5 className="box-pricing-title">Ultimate</h5>
                      <h3 className="box-pricing-price">$1200.00</h3>
                      <div className="box-pricing-time">starting at</div>
                      <div className="box-pricing-divider">
                        <div className="divider"></div><span>Ultimate</span>
                      </div>
                      <ul className="box-pricing-list">
                        <li className="active">Concept development</li>
                        <li className="active">UI design</li>
                        <li className="active">Configuration management</li>
                        <li className="active">Software quality assurance</li>
                        <li className="active">App integration</li>
                      </ul>
                    </div>
                    <div className="box-pricing-button"><a className="button button-lg button-block button-gray-4" href="#">Get started</a></div>
                  </div>
                </div>
              </div>
            </div>
          </section>  */}

  )
}